package DBLesson02;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DBLesson02 {

//	static Boolean Em = true;

	public static void main(String args[]){

		ArrayList<Word> Worda = new ArrayList<Word>();
		List<Word> WordA = new ArrayList<Word>();
		System.out.println("英単語と日本語をスペースで区切って入力して下さい。");

		@SuppressWarnings("resource")
		Scanner sc  = new Scanner(System.in);
		String input = sc.nextLine();


		// ここから記述してください

		int index = 0;
		try{
			while(!input.equals("e")){

				String[] tmp = new String[2];

				tmp = input.split(" ");

				//tmp[0] = inputCheck(tmp[0]);

				Worda.add(new Word(tmp[0],tmp[1]));

				index++;
				if(index >= 5) {
					System.out.println("登録制限を超えました。登録済みのデータは以下になります。");
					break;
				}
				System.out.println("次の単語を入力してください\"e\"で終了します。");
				input = sc.nextLine();
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("用意した容量をオーバーしました。");
		}

//		if(Em) {
		int arrayresult;

			WordDAO worddao = new WordDAO();

			arrayresult = worddao.registWords(Worda);

			System.out.println(arrayresult + "件のデータを登録しました。");
			System.out.println("登録されているデータは以下の通りです。");
			WordA = worddao.getWords();

			int i;
			for(i = 0;i < WordA.size();i++) {
				System.out.println(WordA.get(i));
			}
			System.out.println("登録されているデータは"+ i +"件です。");

//		}

	}


//	private static String inputCheck(String str) {
//
//		String normalize;
//
//		normalize = Normalizer.normalize(str, Normalizer.Form.NFKC);
//
//		char[] charArray = normalize.toCharArray();
//
//		 for( int i=0; i<str.length(); i++ ) {
//	            if( (charArray[i] >= 0x41 && charArray[i] <= 0x5A ) || ( charArray[i] >= 0x61 && charArray[i] <= 0x7A)){
//
//	            }else {
//	                System.out.println( "英字以外が含まれています！！" );
//	            	Em = false;
//	            }
//	        }
//
//		return  String.valueOf(charArray);
//
//	}
//
//
}
